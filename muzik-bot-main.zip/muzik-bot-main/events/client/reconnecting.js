//here the event starts
module.exports = client => {
    console.log(`Reconnceting at ${new Date()}.`.bgYellow.black)
}
/**
  * @INFO
  * Bot Coded by Tomato#6966 | https://discord.gg/FQGXbypRf8
  * @INFO
  * Work for Milrato Development | https://milrato.eu
  * @INFO
  * Please mention him / Milrato Development, when using this Code!
  * @INFO
*/
